ALTER TABLE staff 
ADD COLUMN contract_end_date TEXT,
ADD COLUMN employment_status TEXT;

ALTER TABLE staff ADD COLUMN start_date TEXT;

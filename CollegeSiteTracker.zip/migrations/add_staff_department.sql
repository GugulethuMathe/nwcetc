ALTER TABLE staff ADD COLUMN department TEXT;
